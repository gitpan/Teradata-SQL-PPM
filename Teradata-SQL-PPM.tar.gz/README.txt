This is a PPM distribution of Teradata::SQL 0.05. It was compiled on May 13,
2008, under this environment:

Microsoft Windows XP [Version 5.1.2600]
(C) Copyright 1985-2001 Microsoft Corp.

This is perl, v5.8.8 built for MSWin32-x86-multi-thread
(with 18 registered patches, see perl -V for more detail)

Binary build 822 [280952] provided by ActiveState http://www.ActiveState.com
Built Jul 31 2007 19:34:48

CLIv2 12.00.00.00

----------
TO INSTALL
----------

Add Teradata-SQL.ppd and Teradata-SQL.tar.gz to any directory.

In PPM (Edit > Preferences > Repositories), add that directory as a repository.

Install from PPM.
