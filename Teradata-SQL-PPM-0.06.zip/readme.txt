This is a PPM distribution of Teradata::SQL 0.06. It was compiled on October 27,
2008, under this environment:

Microsoft Windows XP [Version 5.1.2600] [SP2]
(C) Copyright 1985-2001 Microsoft Corp.

This is perl, v5.10.0 built for MSWin32-x86-multi-thread
(with 5 registered patches, see perl -V for more detail)

Binary build 1003 [285500] provided by ActiveState http://www.ActiveState.com
Built May 13 2008 16:52:49

CLIv2 12.00.00.02

Microsoft (R) 32-bit C/C++ Optimizing Compiler Version 15.00.21022.08 for 80x86

Microsoft (R) Program Maintenance Utility Version 9.00.21022.08


----------
TO INSTALL
----------

Add Teradata-SQL-0.06.ppd and Teradata-SQL-0.06.tar.gz to any directory.

In PPM (Edit > Preferences > Repositories), add that directory as a repository.

Install from PPM.
